from main import get_omars_analysis
from main import code